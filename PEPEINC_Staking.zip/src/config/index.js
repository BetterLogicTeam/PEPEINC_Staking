export const BRIDGE_URL = "https://bridge.walletconnect.org";
// export const RPC_URL = "https://data-seed-prebsc-1-s3.binance.org:8545/"; binance testnet
export const RPC_URL = "https://bsc.publicnode.com"; //mainnet
export const CHAIN_ID = 56;
